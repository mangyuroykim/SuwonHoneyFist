package org.SuwonHoneyFist.day03.control.loop;

public class Exam_While {
	public static void main(String[] args) {
		// 2. While문
		// 문법
		// 초기식;
		// while(조건식) { 실행문장; 증가식; }
		int i = 0;
		while (i < 10) {
			System.out.print(i);
			i++;
			// for문은 ()안에다가 변수를 따로 지정 가능하니까 유용
//			while은 초기식이 바깥에 있어서 동작 안할 수 있음

		}
	}
}
