package org.SuwonHoneyFist.day03.loop.exercise;

import java.util.Scanner;

public class Exercise_Loop5 {
    public static void main(String[] args) {
        // 사용자로부터 입력 받은 숫자의 단을 출력하세요.
        Scanner sc = new Scanner(System.in);
        System.out.print("숫자를 입력하세요: ");
        int dan = sc.nextInt();
        
        for (int i = 1; i <= 9; i++) {
            int result = dan * i;
            System.out.println(dan + " * " + i + " = " + result);
        }
    }
}
