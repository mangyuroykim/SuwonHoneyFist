package org.SuwonHoneyFist.day03.loop.exercise;

public class Exercise_Loop_2_4 {

}
