package org.SuwonHoneyFist.day03.loop.exercise;

import java.util.Scanner;

public class Exercise_while2 {
	public static void main(String [] args) {
		// while문을 이용하여 -1이 입력될때까지
		// 정수를 입력 받고
		// -1이 입력되면 입력한 수의 합을 출력하시오.
		Scanner sc = new Scanner(System.in);
		int i = 0;
		int sum = 0;
		while( i != -1) {
			System.out.print("정수를 입력하세요 : ");
			i = sc.nextInt();
			if(i != -1) {
				sum += i;
			}
			else {
				System.out.println("입력한 수의 합 : " + sum );
			}
		}
	}
/*		정수를 10번 입력받아서 합을 출력하는 프로그램부터 
 * 		만들어보자.
 * 		int i = 0;
 * 		int sum = 0;
 * 		
 * 		int val = 0;
 * 		
 * 		while(val >= 0) {
 * 			System.out.print("정수 하나 입력 : ");
 * 				val = sc.nextInt();
 * 				sum += val; *이건 수정해야함 틀림*
 * 		}////////////////////////////////////////////
 * 		int lastNum;
 * 		while((lastNum = sc.nextInt()) != -1) {
 * 			sum += lastNum;
 * 		}
 * 		System.out.println("총합 : " + sum); * 스프링에서 나옴.
 * 		//////////////////////////////////////////////////
 * 		sum = 0;
 * 		int val
 * 		while(true) {
 * 			System.out.print ("정수 하나 입력 : ");
 * 			val = sc.nextInt();
 * 			if(val == -1) break;
 * 			sum += val;
 * 		}
 * 		System.out.println("총합 : " + sum);
 * 		/////////////////////////////////////////////
 * 		sum = 0;
 * 		System.out.print("정수 하나 입력 : ")
 * 		int input = sc.nextInt();
 * 		while(input !=-1) {
 *  * 		sum += input;
 *  		System.out.print("정수 하나 입력 : ");
 *  		input = sc.nextInt();
 *  	}
 *  	System.out.println("총합 : " + sum);
 *  	///////////////////////////////////////////
 * 		sum	= 0;
 * 		while(i < 10) {
 * 			System.out.print("정수 하나 입력 : ");
 * 			int num = sc.nextInt();
 * 			if(num == -1) break;
 * 			sum += num;
 * 			i++;
 * 		}
 * 		System.out.println("총합 : " + sum);
 *
		
		}
	}
