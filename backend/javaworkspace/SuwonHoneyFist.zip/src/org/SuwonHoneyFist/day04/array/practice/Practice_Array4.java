package org.SuwonHoneyFist.day04.array.practice;

public class Practice_Array4 {
	public static void main(String[] args) {
//		길이가 5인 String배열을 선언하고 
//		“사과”, “귤“, “포도“, “복숭아”, “참외“로 초기화 한 후
//		배열 인덱스를 활용해서 귤을 출력하세요.
		String[] fruits = {"사과","귤","포도","복숭아","참외"};
		for(int i = 0; i < fruits.length; i++ ) {
			if(fruits[i].equals("귤")) { // 문자열 찾을땐 .equals 외우기
				System.out.println(fruits[i]);
				break;
			}
		}

	}
}
