package org.SuwonHoneyFist.day04.control.loop.exercise;

public class Exercise_forDouble1 {
	public static void main(String [] args) {
		// *
		// **
		// ***
		// ****
		// *****
		// ******
		
		for(int star = 1; star < 7; star++) {
			for(int i = 1; i <= star; i++) {
				System.out.print("*");
		}
			System.out.println("");
//		System.out.print("*");
//		System.out.println();
//		
//		System.out.print("*");
//		System.out.print("*");
//		System.out.println();
//
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.println();
//		
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.println();
//		
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.println();
//		
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.print("*");
//		System.out.println();
	}
}
}
