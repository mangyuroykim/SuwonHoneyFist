package jaseupsigan;

import java.util.Scanner;

public class jaseupsigan_practice14 {
	public static void main(String[] args) {
		// 3번
		// 1부터 사용자에게 입력 받은 수까지의 정수들의 합을
		// for문을 이용하여 출력하세요.
		// 정수 하나 입력 : 5
		// 1+2+32+4+5=15
		Scanner scanner = new Scanner(System.in);
		System.out.print("숫자를 입력하세요 : ");
		int num = scanner.nextInt();
		int sum = 0;
		for (int i = 1; i <= num; i++) {
			sum += i;
			if (i < num) {
				System.out.print(i + " + ");
			}else {
				System.out.print(i + " = ");
			}

		}
		System.out.print(sum);

	}
}
