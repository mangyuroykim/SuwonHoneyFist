package jaseupsigan;

public class jaseupsigan_practice20 {

}
