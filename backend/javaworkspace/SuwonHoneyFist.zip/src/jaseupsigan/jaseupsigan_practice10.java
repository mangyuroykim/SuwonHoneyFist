package jaseupsigan;

public class jaseupsigan_practice10 {
	public static void main(String [] args) {
		// while문을 이용하여 1 ~ 100사이의 홀수의 합을 출력하시오
		// 1 ! 100 사이의 합 홀수의 합 : ?
		int num = 1;
		int sum = 0;
		while(num <=100 ) {
			if(num % 2 !=0) {
				sum+=num;				
			}
				num++;
			}
		System.out.print(sum);
		}
	}

