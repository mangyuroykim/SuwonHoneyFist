package kr.or.iei;

import java.util.Random;
import java.util.Scanner;

public class Question2 {
	public static void main(String[] args) {
//		고객 요구사항에 맞춰 가위 바위 보 게임 프로그램을 개발하세요
//
//		고객 요구사항
//		 1. 가위 바위 보 중 하나의 문자열을 입력 받고, 난수를 발생시켜 랜덤하게 가위 바위 보 문자열을 생성한다.
//		 2. 랜덤한 가위 바위 보 문자열과 입력한 문자열이 같으면 아래 실행 결과처럼 비겼다고 출력하고 가위 바위 보 게임을 반복한다.
//		 3 입력한 가위 바위 보 문자열이 랜덤한 가위 바위 보 문자열과 비교하여 가위 바위 보 게임의 룰 대로 이긴 경우 이겼다고 출력, 진 경우 졌다고 출력 후 종료
		Random rand = new Random(); 
				Scanner sc = new Scanner(System.in);
		System.out.print("'가위 바위 보' 중에서 아무 글자나 하나 입력하세요 : ");
		String game = sc.next();
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
}