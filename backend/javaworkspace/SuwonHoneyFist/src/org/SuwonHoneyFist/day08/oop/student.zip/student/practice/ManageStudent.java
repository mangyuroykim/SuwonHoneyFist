package org.SuwonHoneyFist.day08.oop.student.practice;

public class ManageStudent {

}
